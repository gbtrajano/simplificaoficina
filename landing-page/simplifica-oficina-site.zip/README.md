# Landing page — Simplifica Oficina

Abra `index.html` no navegador. Para publicar, copie os dois arquivos HTML desta pasta para a mesma pasta da hospedagem:

- `index.html`: landing page.
- `download.html`: cópia independente da página de download, com guia de instalação.

O visual usa Tailwind CSS compilado e incorporado em cada HTML. Não precisa de React, servidor de aplicação, fontes externas ou CDN. A consulta ao instalador e o download exigem internet.

O plano é apresentado como assinatura mensal, sem preço publicado. A prévia do sistema é ilustrativa e usa dados fictícios. Não foram adicionados depoimentos, números de clientes ou promessas de resultados.

## Atualizações

Os links de download apontam para `download.html`. Nessa página, `RELEASE_MANIFEST` e `RELEASES_URL` definem o canal de distribuição. Se mudar o provedor, ajuste também a validação de domínio e caminho do instalador.

A cópia de download não se sincroniza automaticamente com `../pagina-download/index.html`. Se alterar a página original, atualize esta cópia também.

O CSS incorporado foi gerado com a versão do Tailwind instalada no projeto. Ao adicionar classes utilitárias novas, regenere esse CSS. Os textos podem ser editados diretamente no HTML.
